package com.example.backend.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.backend.entity.Address;
import com.example.backend.entity.Cart;
import com.example.backend.entity.CartItem;
import com.example.backend.entity.Order;
import com.example.backend.entity.OrderItem;
import com.example.backend.entity.OrderStatus;
import com.example.backend.entity.User;
import com.example.backend.repository.AddressRepository;
import com.example.backend.repository.CartRepository;
import com.example.backend.repository.OrderItemRepository;
import com.example.backend.repository.OrderRepository;
import com.example.backend.repository.UserRepository;

@Service
public class OrderService {

    private final UserService userService;
	@Autowired
	private OrderRepository orderRepo;
	
	@Autowired
	private OrderItemRepository orderItemRepo;
	
	@Autowired
	private CartRepository cartRepo;
	
	@Autowired
	private UserRepository userRepo;
	
	@Autowired
	private AddressRepository addressRepo;

    OrderService(UserService userService) {
        this.userService = userService;
    }
	
	public Order placeOrder(Long userId, Long addressId) {
		User user = userRepo.findById(userId).orElseThrow();
		Cart cart = cartRepo.findByUserId(userId).orElseThrow();
		Address address = addressRepo.findById(addressId).orElseThrow();
		
		Order order = new Order();
		order.setUser(user);
		order.setOrderDate(LocalDateTime.now());
		order.setStatus(OrderStatus.PENDING);
		order.setShippingAddress(address);
	
		List<OrderItem> orderItems = new ArrayList<>();
		double total =0;
		
		for (CartItem cartItem : cart.getItems()) {
			OrderItem orderItem = new OrderItem();
			orderItem.setProduct(cartItem.getProduct());
			orderItem.setQuantity(cartItem.getQuantity());
			
			double price = cartItem.getProduct().getPrice()* cartItem.getQuantity();
			orderItem.setPrice(price);
			orderItem.setOrder(order);
			
			total += price;
			orderItems.add(orderItem);
		}
		order.setItems(orderItems);
		order.setTotalAmount(total);
		
		Order saveOrder = orderRepo.save(order);
		
		cart.getItems().clear();
		cartRepo.save(cart);
		
		return saveOrder;
	}
	
	public List<Order> getOrdersByUserId(Long userId){
		User user = userRepo.findById(userId).orElseThrow();
		return orderRepo.findAll().stream()
				.filter(o ->o.getUser().getId().equals(user.getId()))
				.toList();
	}
	
	public Order getOrderById(Long orderId) {
	    return orderRepo.findById(orderId)
	            .orElseThrow(() -> new RuntimeException("Order not found"));
	}

	public void deleteOrder(Long orderId) {
	    orderRepo.deleteById(orderId);
	}

}

