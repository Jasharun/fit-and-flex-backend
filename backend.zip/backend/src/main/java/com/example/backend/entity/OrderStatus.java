package com.example.backend.entity;

public enum OrderStatus {
	PENDING,
	CONFIRMED,
	CANCELLED,
	SHIPPED,
	DELIVERED

}
