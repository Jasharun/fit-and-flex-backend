// src/main/java/com/example/backend/service/CartService.java
package com.example.backend.service;

import java.util.ArrayList;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.backend.entity.Cart;
import com.example.backend.entity.CartItem;
import com.example.backend.entity.Product;
import com.example.backend.entity.User;
import com.example.backend.repository.CartRepository;
import com.example.backend.repository.ProductRepository;
import com.example.backend.repository.UserRepository;

@Service
public class CartService {

    private final CartRepository cartRepo;
    private final UserRepository userRepo;
    private final ProductRepository productRepo;

    public CartService(CartRepository cartRepo, UserRepository userRepo, ProductRepository productRepo) {
        this.cartRepo = cartRepo;
        this.userRepo = userRepo;
        this.productRepo = productRepo;
    }

    @Transactional
    public Cart getCartByUserId(Long userId) {
        return cartRepo.findByUserId(userId).orElseGet(() -> {
            User u = userRepo.findById(userId)
                    .orElseThrow(() -> new IllegalArgumentException("User not found: " + userId));
            Cart c = new Cart();
            c.setUser(u);
            c.setItems(new ArrayList<>());
            return cartRepo.save(c);
        });
    }

    @Transactional
    public Cart addItemToCart(Long userId, Long productId, int quantity) {
        Cart cart = cartRepo.findByUserId(userId).orElseGet(() -> {
            User u = userRepo.findById(userId)
                    .orElseThrow(() -> new IllegalArgumentException("User not found: " + userId));
            Cart c = new Cart();
            c.setUser(u);
            c.setItems(new ArrayList<>());
            return cartRepo.save(c);
        });

        if (cart.getItems() == null) cart.setItems(new ArrayList<>());

        Product product = productRepo.findById(productId)
                .orElseThrow(() -> new IllegalArgumentException("Product not found: " + productId));

        CartItem existing = cart.getItems().stream()
                .filter(i -> i.getProduct().getId().equals(productId))
                .findFirst()
                .orElse(null);

        if (existing == null) {
            CartItem item = new CartItem();
            item.setCart(cart);
            item.setProduct(product);
            item.setQuantity(quantity);
            cart.getItems().add(item);
        } else {
            existing.setQuantity(existing.getQuantity() + quantity);
        }

        return cartRepo.save(cart);
    }
}
