// src/main/java/com/example/backend/service/WishlistService.java
package com.example.backend.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.backend.entity.Product;
import com.example.backend.entity.User;
import com.example.backend.entity.Wishlist;
import com.example.backend.repository.ProductRepository;
import com.example.backend.repository.UserRepository;
import com.example.backend.repository.WishlistRepository;

@Service
public class WishlistService {

    private final WishlistRepository wishlistRepo;
    private final UserRepository userRepo;
    private final ProductRepository productRepo;

    public WishlistService(WishlistRepository wishlistRepo, UserRepository userRepo, ProductRepository productRepo) {
        this.wishlistRepo = wishlistRepo;
        this.userRepo     = userRepo;
        this.productRepo  = productRepo;
    }

 // WishlistService.java
    @Transactional
    public Wishlist addToWishlist(Long userId, Long productId) {
      User user = userRepo.findById(userId).orElseThrow(() -> new IllegalArgumentException("User not found"));
      Product product = productRepo.findById(productId).orElseThrow(() -> new IllegalArgumentException("Product not found"));

      Wishlist wishlist = wishlistRepo.findByUserId(userId).orElseGet(() -> {
        Wishlist w = new Wishlist();
        w.setUser(user);
        w.setProducts(new ArrayList<>()); // ensure not null
        return wishlistRepo.save(w);
      });

      if (wishlist.getProducts() == null) {
        wishlist.setProducts(new ArrayList<>());
      }
      if (!wishlist.getProducts().contains(product)) {
        wishlist.getProducts().add(product);
        wishlist = wishlistRepo.save(wishlist);
      }
      return wishlist;
    }


    @Transactional(readOnly = true)
    public List<Product> getWishlist(Long userId) {
        return wishlistRepo.findByUserId(userId)
                .map(Wishlist::getProducts)
                .orElseGet(Collections::emptyList);
    }

    @Transactional
    public void removeFromWishlist(Long userId, Long productId) {
        wishlistRepo.findByUserId(userId).ifPresent(wl -> {
            if (wl.getProducts() != null) {
                wl.getProducts().removeIf(p -> p.getId().equals(productId));
            }
            wishlistRepo.save(wl);
        });
    }
}
