package com.example.backend.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.backend.entity.User;
import com.example.backend.repository.UserRepository;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepo;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public Optional<User> findByEmail(String email) {
        if (email == null) return Optional.empty();
        return userRepo.findByEmail(email.trim().toLowerCase());
    }

    /**
     * Create or update a user.
     * - Normalizes email (trim + lowercase)
     * - Prevents duplicate email for different users
     * - BCrypt-encodes password if it's a new raw password
     */
    @Transactional
    public User save(User u) {
        if (u == null) throw new IllegalArgumentException("User cannot be null");

        // Normalize email
        if (u.getEmail() == null || u.getEmail().isBlank()) {
            throw new IllegalArgumentException("Email is required");
        }
        String normalizedEmail = u.getEmail().trim().toLowerCase();
        u.setEmail(normalizedEmail);

        // Enforce unique email (allow same user to keep their own email)
        Optional<User> existing = userRepo.findByEmail(normalizedEmail);
        if (existing.isPresent() && (u.getId() == null || !existing.get().getId().equals(u.getId()))) {
            throw new IllegalStateException("Email already exists");
        }

        // Encode password if provided as raw (i.e., not an existing bcrypt hash)
        if (u.getPassword() != null && !u.getPassword().isBlank()) {
            String pw = u.getPassword();
            // Keep if it already looks like a bcrypt hash; else encode
            if (!pw.startsWith("$2a$") && !pw.startsWith("$2b$") && !pw.startsWith("$2y$") && !pw.startsWith("{bcrypt}")) {
                u.setPassword(passwordEncoder.encode(pw));
            }
        }

        return userRepo.save(u);
    }

    public String encodePassword(String password) {
        return passwordEncoder.encode(password);
    }

    public List<User> getAllUsers() {
        return userRepo.findAll();
    }

    public void deleteAllUsers() {
        userRepo.deleteAll();
    }
}
