package com.example.backend.dto;

import java.util.Date;
import java.util.List;

public class OrderDTO {
	 private Long orderId;
	    private Long userId;
	    private List<OrderItemDTO> items;
	    private double totalAmount;
	    private String status;
	    private Date createdAt;

	    // Constructors
	    public OrderDTO() {}

	    public OrderDTO(Long orderId, Long userId, List<OrderItemDTO> items, double totalAmount, String status, Date createdAt) {
	        this.orderId = orderId;
	        this.userId = userId;
	        this.items = items;
	        this.totalAmount = totalAmount;
	        this.status = status;
	        this.createdAt = createdAt;
	    }

		public Long getOrderId() {
			return orderId;
		}

		public void setOrderId(Long orderId) {
			this.orderId = orderId;
		}

		public Long getUserId() {
			return userId;
		}

		public void setUserId(Long userId) {
			this.userId = userId;
		}

		public List<OrderItemDTO> getItems() {
			return items;
		}

		public void setItems(List<OrderItemDTO> items) {
			this.items = items;
		}

		public double getTotalAmount() {
			return totalAmount;
		}

		public void setTotalAmount(double totalAmount) {
			this.totalAmount = totalAmount;
		}

		public String getStatus() {
			return status;
		}

		public void setStatus(String status) {
			this.status = status;
		}

		public Date getCreatedAt() {
			return createdAt;
		}

		public void setCreatedAt(Date createdAt) {
			this.createdAt = createdAt;
		}
	    

}
