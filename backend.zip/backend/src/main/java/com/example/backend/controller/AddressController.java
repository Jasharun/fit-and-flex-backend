// src/main/java/com/example/backend/controller/AddressController.java
package com.example.backend.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.backend.entity.Address;
import com.example.backend.service.AddressService;

@RestController
@RequestMapping("/api/address")
// @CrossOrigin(origins = "http://localhost:5173") // <- optional if CORS needed here
public class AddressController {

    @Autowired
    private AddressService addressService;

    // Create / add a new address for a user
    @PostMapping("/add/{userId}")
    public Address addAddress(@PathVariable Long userId, @RequestBody Address address) {
        return addressService.addAddress(userId, address);
    }

    // List all addresses for a user
    @GetMapping("/user/{userId}")
    public List<Address> getAddresses(@PathVariable Long userId) {
        return addressService.getAddresses(userId);
    }

    // Delete a specific address (simple version without ownership check)
    @DeleteMapping("/delete/{addressId}")
    public void deleteAddress(@PathVariable Long addressId) {
        addressService.deleteAddress(addressId);
    }

    /*
    // If you implemented the safer delete(userId, addressId) in the service:
    @DeleteMapping("/user/{userId}/{addressId}")
    public void deleteAddress(@PathVariable Long userId, @PathVariable Long addressId) {
        addressService.deleteAddress(userId, addressId);
    }
    */
}
