// src/main/java/com/example/backend/controller/CartController.java
package com.example.backend.controller;

import org.springframework.web.bind.annotation.*;

import com.example.backend.entity.Cart;
import com.example.backend.service.CartService;

@RestController
@RequestMapping("/api/cart")
public class CartController {

    private final CartService cartService;
    public CartController(CartService cartService) { this.cartService = cartService; }

    @GetMapping("/{userId}")
    public Cart getCart(@PathVariable Long userId) {
        return cartService.getCartByUserId(userId);
    }

    @PostMapping("/add")
    public Cart addItemToCart(@RequestParam Long userId,
                              @RequestParam Long productId,
                              @RequestParam int quantity) {
        return cartService.addItemToCart(userId, productId, quantity);
    }
}
