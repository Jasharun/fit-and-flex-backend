// src/main/java/com/example/backend/controller/WishlistController.java
package com.example.backend.controller;

import java.util.List;

import org.springframework.web.bind.annotation.*;

import com.example.backend.entity.Product;
import com.example.backend.entity.Wishlist;
import com.example.backend.service.WishlistService;

@RestController
@RequestMapping("/api/wishlist")
public class WishlistController {

    private final WishlistService wishlistService;
    public WishlistController(WishlistService wishlistService) { this.wishlistService = wishlistService; }

    @PostMapping("/add")
    public Wishlist addWishlist(@RequestParam Long userId, @RequestParam Long productId) {
        return wishlistService.addToWishlist(userId, productId);
    }

    @GetMapping
    public List<Product> getWishlist(@RequestParam Long userId) {
        return wishlistService.getWishlist(userId);
    }

    @DeleteMapping("/remove")
    public void removeWishlist(@RequestParam Long userId, @RequestParam Long productId) {
        wishlistService.removeFromWishlist(userId, productId);
    }
}
