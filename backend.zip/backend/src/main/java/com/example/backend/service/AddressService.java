// src/main/java/com/example/backend/service/AddressService.java
package com.example.backend.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.backend.entity.Address;
import com.example.backend.entity.User;
import com.example.backend.repository.AddressRepository;
import com.example.backend.repository.UserRepository;

@Service
public class AddressService {

    @Autowired
    private AddressRepository addressRepo;

    @Autowired
    private UserRepository userRepo;

    public Address addAddress(Long userId, Address address) {
        User user = userRepo.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));
        address.setUser(user);
        return addressRepo.save(address);
    }

    public List<Address> getAddresses(Long userId) {
        // Don’t call user.getAddresses(); we don’t have that mapping on User.
        return addressRepo.findByUserId(userId);
    }

    // keep your simple delete or enforce ownership, your call:
    public void deleteAddress(Long addressId) {
        addressRepo.deleteById(addressId);
    }
    /*
    // Safer version (optional):
    public void deleteAddress(Long userId, Long addressId) {
        Address addr = addressRepo.findById(addressId)
            .orElseThrow(() -> new RuntimeException("Address not found"));
        if (!addr.getUser().getId().equals(userId)) {
            throw new RuntimeException("Address does not belong to user");
        }
        addressRepo.delete(addr);
    }
    */
}
