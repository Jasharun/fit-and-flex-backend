package com.example.backend.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.backend.entity.Product;
import com.example.backend.service.ProductService;

import jakarta.annotation.PostConstruct;

@RestController
@RequestMapping("/api/products")
public class ProductController {

    @Autowired
    private ProductService productService;

    @GetMapping
    public List<Product> getAllProducts() {
        return productService.getAllProducts();
    }

    @PostMapping
    public Product createProduct(@RequestBody Product p) {
        return productService.saveProduct(p);
    }

    @GetMapping("/{id}")
    public Product getProductById(@PathVariable Long id) {
        return productService.getProductById(id);
    }

    @PutMapping("/{id}")
    public Product updateProduct(@PathVariable Long id, @RequestBody Product updatedProduct) {
        return productService.updateProduct(id, updatedProduct);
    }

    @DeleteMapping("/{id}")
    public void deleteProduct(@PathVariable Long id) {
        productService.deleteProduct(id);
    }

    @PostConstruct
    public void initProducts() {
        // Seed only once
        if (productService.count() > 0) return;

        // --- Jerseys (description holds the slug "jerseys") ---
        productService.saveProduct(new Product("Barca Messi",               "jerseys", 299.00, "/assets/products/messi.jpeg"));
        productService.saveProduct(new Product("Ronaldo Sporting Portugal", "jerseys", 299.00, "/assets/products/cr7-sporting.jpeg"));
        productService.saveProduct(new Product("Santos Neymar Jr",          "jerseys", 299.00, "/assets/products/nj.jpeg"));
        productService.saveProduct(new Product("Chelsea Drogba",            "jerseys", 299.00, "/assets/products/drogba.jpeg"));
        productService.saveProduct(new Product("Real Madrid Beckham",       "jerseys", 299.00, "/assets/products/beckham.jpeg"));
        productService.saveProduct(new Product("Al-Nassr CR7",              "jerseys", 299.00, "/assets/products/cr7.jpeg"));
        productService.saveProduct(new Product("ACM Maldini",               "jerseys", 299.00, "/assets/products/maldini.jpeg"));
        productService.saveProduct(new Product("Barca Yamal",               "jerseys", 299.00, "/assets/products/yamal.jpeg"));
        productService.saveProduct(new Product("French Zidane",             "jerseys", 299.00, "/assets/products/zidane.jpeg"));

        // --- Other categories (same idea: description is the slug) ---
        productService.saveProduct(new Product("Premium Cotton T-Shirt", "t-shirts",   19.00, "/assets/products/tshirt-basic.jpg"));
        productService.saveProduct(new Product("Oxford Casual Shirt",    "shirts",     39.00, "/assets/products/shirt-oxford.jpg"));
        productService.saveProduct(new Product("Fleece Hoodie",          "hoodies",    59.00, "/assets/products/hoodie-fleece.jpg"));
        productService.saveProduct(new Product("Windbreaker Jacket",     "jackets",    69.00, "/assets/products/jacket-wind.jpg"));
        productService.saveProduct(new Product("Slim Fit Jeans",         "jeans",      49.00, "/assets/products/jeans-slim.jpg"));
        productService.saveProduct(new Product("Logo Cap",               "accessories",15.00, "/assets/products/cap-logo.jpg"));
    }

}

