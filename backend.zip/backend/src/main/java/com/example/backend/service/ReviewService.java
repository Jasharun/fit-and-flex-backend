package com.example.backend.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.backend.entity.Product;
import com.example.backend.entity.Review;
import com.example.backend.entity.User;
import com.example.backend.repository.ProductRepository;
import com.example.backend.repository.ReviewRepository;
import com.example.backend.repository.UserRepository;

@Service
public class ReviewService {
	@Autowired
	private ReviewRepository reviewRepo;
	@Autowired
	private UserRepository userRepo;
	@Autowired
	private ProductRepository
	productRepo;
	
	 public Review addReview(Long userId, Long productId, String comment, int rating) {
	        User user = userRepo.findById(userId).orElseThrow();
	        Product product = productRepo.findById(productId).orElseThrow();

	        Review review = new Review();
	        review.setUser(user);
	        review.setProduct(product);
	        review.setComment(comment);
	        review.setRating(rating);
	        review.setReviewData(LocalDateTime.now());

	        return reviewRepo.save(review);
	    }

	    public List<Review> getReviewsForProduct(Long productId) {
	        Product product = productRepo.findById(productId).orElseThrow();
	        return reviewRepo.findByProduct(product);
	    }

}

