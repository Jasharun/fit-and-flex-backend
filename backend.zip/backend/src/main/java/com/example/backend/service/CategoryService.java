package com.example.backend.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.backend.entity.Category;
import com.example.backend.repository.CategoryRepository;

@Service
public class CategoryService {
	
	@Autowired
	private CategoryRepository categoryRepo;
	public List<Category> getAllCategories(){
		return categoryRepo.findAll();
	}
	public Category saveCategory(Category c) {
		return categoryRepo.save(c);
	}

}
